####
#MMURuseR group
#intro to {ggplot2}
#2016.12.14
#files :: http://operorgenetic.com/wp > home tab > ggplot2.tutorial

####
#Contents
#part 1 R graphing background
#part 2 gplot2 intro to qplot()
#part 3 a "full speed" ggplot


####
#part 1
#R Graphing Background 

#Ed surface
setwd("C:/Users/Ed/Dropbox/WORK/statistics.resources/.MMU.RuseR.group/2016.12.ggplot2")

####
#1.1 intro to R graphics
#-the idea is to "build up" a graph
#-you can think of this as layers

data(iris) #Fisher's iris data
?iris
head(iris)

#basic plot
plot(iris$Petal.Length~iris$Sepal.Length)

#basic plot + titles
plot(iris$Petal.Length~iris$Sepal.Length,
     main="Fisher's iris data",
     xlab="Sepal Length (cm)",
     ylab="Petal Length (cm)")

####
#1.2 making base graphics work for you
#sex it up
#add color for species and a legend
plot(iris$Petal.Length~iris$Sepal.Length,
     main="Fisher's iris data",
     xlab="Sepal Length (cm)",
     ylab="Petal Length (cm)",
     col=c("red", "blue", "green")[iris$Species],
     pch=c(1,2,3)[iris$Species])
legend(x=4.35, y=6.8, 
       legend=c("setosa", "versicolor", "virginica"),
       col=c("red", "blue", "green"),
       pch=c(1,2,3),
       bty="n")


####
#part 2 
#ggplot2 intro to qplot()
#https://cran.r-project.org/web/packages/ggplot2/index.html

#Edwin Chen's github ggplot2 tutorial
#https://github.com/echen/ggplot2-tutorial

##ggplot2==Hadley Wickham
##inspired by Grammar of Graphics, Leland Wilkinson
##basically, make awesome graphs, packed with info, dead easy

####
#2.1 qplot() make basic awesome graphs
library(ggplot2)
qplot(x=Sepal.Length, y=Petal.Length, data=iris)
# Plot Sepal.Length vs. Petal.Length, using data from the `iris` data frame.
# * First argument `Sepal.Length` goes on the x-axis.
# * Second argument `Petal.Length` goes on the y-axis.
# * `data = iris` means to look for this data in the `iris` data frame.

qplot(Sepal.Length, Petal.Length, data = iris, color = Species) #not bad...
#note, ideally you have an expectation about graphing data
#but the simple tools, small amount of code required help

####
#2.2 size and alpha of points...

#symbol size
qplot(Sepal.Length, Petal.Length, data = iris, color = Species, 
      size = Petal.Width)

#symbol alpha
#By setting the alpha of each point to 0.7, we reduce the effects of overplotting.
qplot(Sepal.Length, Petal.Length, data = iris, color = Species, 
      size = Petal.Width, 
      alpha = I(0.7))

#labels like above
qplot(Sepal.Length, Petal.Length, data = iris, color = Species,
      size = Petal.Width, 
      alpha = I(0.7),
      xlab = "Sepal Length", ylab = "Petal Length", 
      main = "Sepal vs. Petal Length in Fisher's Iris data")

####
#2.3 how about some other "geoms"
?qplot #note geom = "auto" argument

####
#POINT geom
#we already used the point geom, the default
#These two are equivalent:
qplot(Sepal.Length, Petal.Length, data = iris, geom = "point")
qplot(Sepal.Length, Petal.Length, data = iris)

####
#BAR geom
movies = data.frame(
  director = c("spielberg", "spielberg", "spielberg", "jackson", "jackson"),
  movie = c("jaws", "avatar", "schindler's list", "lotr", "king kong"),
  minutes = c(124, 163, 195, 600, 187)
)
# Plot the number of movies each director has.
qplot(director, data = movies, geom = "bar", ylab = "# movies")
# By default, the height of each bar is simply a count.

# But we can also supply a different weight.
# Here the height of each bar is the total running time of the director's movies.
qplot(director, weight = minutes, data = movies, geom = "bar", ylab = "total length (min.)")

####
#LINE geom 1
qplot(Sepal.Length, Petal.Length, data = iris, geom = "line", color = Species) 
# Using a line geom doesn't really make sense here, but hey.

####
#LINE geom 2
# `Orange` is another built-in data frame that describes the growth of orange trees.
qplot(age, circumference, data = Orange, geom = "line",
      colour = Tree,
      main = "How does orange tree circumference vary with age?")

####
#MULTIPLE geoms omg!
# We can also plot both points and lines.
qplot(age, circumference, data = Orange, geom = c("point", "line"), colour = Tree)

####
#part 3 a "full speed" ggplot() example...

#this is the part that actually makes the graph
#might set this up as a file output?

####
#3.1 get the main data in
#explain this is student satisfaction by year and by area of satisfaction for NSS subset
myData <- read.csv("satisfiedGgplot.csv")
head(myData)

####
#3.2
#make the base layer for the fig = mapping
#not aes function used in the mapping argument
p <- ggplot(myData, mapping=aes(x=factor(year), y=agree))

#jitter the data points with geom_jitter
p + geom_jitter(position=position_jitter(width=.4), color="blue", size=.5)

#boxplot with grotesquely large outliers
p + geom_boxplot(outlier.size=2) + facet_wrap(~q, ncol=7) 

#make text big for high res. output
p + theme(text = element_text(size=30), 
               axis.text.x = element_text(angle = 45, size=18, hjust = 0.8))




####
#3.3 Put it all together, tweaked for output to file
p <- ggplot(myData, mapping=aes(x=factor(year), y=agree))
p <- p + geom_jitter(position=position_jitter(width=.4), color="blue", size=.5)
p <- p + geom_boxplot(outlier.size=2) + facet_wrap(~q, ncol=7) 
p <- p + theme(text = element_text(size=30), 
               axis.text.x = element_text(angle = 45, size=18, hjust = 0.8))
p <- p + theme(legend.position="none") +
  labs(x="Year", y="Proportion agreement")
p + theme_minimal()
p + theme_bw()
####
#3.4
#output to file
res<-300
png(filename="myBoxplot.png", width=6*res, height=4*res)
p
dev.off()
