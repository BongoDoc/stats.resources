####
#MMU R Users group meeting
#2017.02.15
#Random Forests Part I: a filthy intro
#much of this was adapted from: 
#https://eight2late.wordpress.com/2016/09/20/a-gentle-introduction-to-random-forests-using-r/

####
#Set up and environment

#Ed hom PC
setwd("C:/Users/Ed/Dropbox/WORK/statistics.resources/.MMU.RuseR.group/2017.02.15 randomForest")
#Ed work PC
setwd("E:/Dropbox/WORK/statistics.resources/.MMU.RuseR.group/2017.02.15 randomForest")

#libraries
library(rpart) #for CART methods
library(mlbench)  #for Glass dataset
library(randomForest) #for plain ol' rF

####
#Contents
# 00 The basic Idea, background, etc.
# 01 Recursive partitioning and Regression Trees
# 02 rpart tree averaging
# 03 Plain ol' Random Forest
# 04 Exploring Random Forest outputs
# 05 Some data to play with on your own
# 06 References

####
# 00 The basic Idea, background, etc.

###
# who invented it?
# Breiman 2001
# http://link.springer.com/article/10.1023/A:1010933404324

###
# where I first heard of it: 
# Liaw & Weiner 2002
# http://ai2-s2-pdfs.s3.amazonaws.com/6e63/3b41d93051375ef9135102d54fa097dc8cf8.pdf

###
# where I first took it seriously:
# Cutler et al. 2007
# http://onlinelibrary.wiley.com/doi/10.1890/07-0539.1/full

###
# a paper I have found very useful
# Genuer et al. 2010
# http://www.sciencedirect.com/science/article/pii/S0167865510000954

###
# You can use Random Forests and associated tools for 4 things
# a) identify VARIABLE IMPORTANCE
# b) EDA and understanding the "structure" of your data
# c) DATA REDUCTION
# d) MODELLING (in the strict sense)

###
# There are 3 phases in any data analysis that are particularly important in rF 
# important in any machine learning analysis
# a) data prep: cleaning, getting data into R, factor structure, identifying effect size etc.
# b) the analysis (this is the easiest part)
# c) validation and analysis iteration

# relative immportance of the three phases == a > c > b
# in my experience a is an afterthought and c is ignored


####
# 01 Recursive partitioning and Regression Trees
#Decision trees using rpart
#rpart == Recursive Partitioning and Regression Trees
#This is like a single tree plucked from the Forest...

#load Glass data
data("Glass")
?Glass
str(Glass)

#set seed to ensure reproducible results (for runif())
#then split data into training and test sets
#note the importance of REPRODUCIBLE DATA ANALYSIS
set.seed(42)
Glass[, "train"] <- ifelse( runif(nrow(Glass)) < 0.8, 1, 0)

#separate training and test sets
trainGlass <- Glass[Glass$train==1, ]
testGlass <- Glass[Glass$train==0, ]

#get column index of train flag
#note use of grep() <- useful for matching strings of text
trainColNum <- grep("train", names(trainGlass))

#remove train flag column from train and test sets
trainGlass <- trainGlass[ , -trainColNum]
testGlass <- testGlass[ , -trainColNum]

#get column index of predicted variable in dataset
typeColNum <- grep("Type", names(Glass))

#build model
rpart_model <- rpart(Type ~., data = trainGlass, method = "class")

#plot tree
plot(rpart_model) ; text(rpart_model)

#...and the moment of reckoning
rpart_predict <- predict(object = rpart_model, 
                         newdata = testGlass[, -typeColNum], 
                         type = "class")
mean(rpart_predict == testGlass$Type)
#[1] 0.6744186
#basically, our tree predicts Glass Type correctly about 67% of the time


####
# 02 rpart tree averaging
#Can we improve our previous prediction by making a load of trees?

#function to do multiple runs
multiple_runs <- function(train_fraction, n, dataset){
  fraction_correct <- rep(NA, n)
  set.seed(42)
  for (i in 1:n){
    dataset[ , "train"] <- ifelse(runif(nrow(dataset)) < 0.8, 1, 0)
    trainColNum <- grep("train", names(dataset))
    typeColNum <- grep("Type", names(dataset))
    trainset <- dataset[dataset$train==1, -trainColNum]
    testset <- dataset[dataset$train==0, -trainColNum]
    rpart_model <- rpart(Type~., data = trainset, method= "class")
    rpart_test_predict <- predict(rpart_model, testset[, -typeColNum], type= "class")
    fraction_correct[i] <- mean(rpart_test_predict == testset$Type)
  }
  return(fraction_correct)
}
#50 runs, no pruning
n_runs <- multiple_runs(train_fraction=0.8, n=50, dataset=Glass)
mean(n_runs)
#[1] 0.6874315
sd(n_runs)
#[1] 0.0530809

#Hmmm no difference really...


####
# 03 Plain ol' Random Forest

#set seed to ensure reproducible results
#split into training and test sets
set.seed(42)
Glass[ , "train"] <- ifelse(runif(nrow(Glass)) < 0.8, 1, 0)

#separate training and test sets
trainGlass <- Glass[Glass$train==1, ]
testGlass <- Glass[Glass$train==0, ]

#get column index of train flag
trainColNum <- grep("train", names(trainGlass))

#remove train flag column from train and test sets
trainGlass <- trainGlass[, -trainColNum]
testGlass <- testGlass[, -trainColNum]

#get column index of predicted variable in dataset
typeColNum <- grep("Type", names(Glass))

#build your model :: ?randomForest
Glass.rf <- randomForest(formula = Type ~., data = trainGlass, 
                         importance=TRUE, xtest = testGlass[ , -typeColNum], 
                         ntree = 1000)


#Get summary info
Glass.rf 
# discuss:
# OOB ERROR
# CONFUSION MATRIX
# overall error is ~24% == okay
# but yucky too
# look at the rows of the confusion matrix


plot(Glass.rf$confusion[, "class.error"]~apply(X = Glass.rf$confusion[, 1:6], 
                                     MARGIN = 1,
                                     FUN = sum),
     ylab = "Class Error",
     xlab = "N in Cell")

# To misquote Johnny Cash: I've seen less even rF matrices, but I can't really remember when

####
# 04 Exploring Random Forest outputs
#how good are predictions?

#accuracy for test set
mean(Glass.rf$test$predicted == testGlass$Type)
#[1] 0.8372093  <- not bad

#confusion matrix
table(Glass.rf$test$predicted,testGlass$Type) #<- not bad

#OOB test and predicted values accuracy are comparable and pretty good

#measures for how good a variable is: gini and accuracy

##
#Mean Decrease in Gini
#This is a measure of how "pure" (1 classification type) a node is DECREASED
#when a particular variable is 
#excluded to make a split at a tree leaf
#Scale is relative, higher == the variable is a better predictor

##
#Mean decrease in accuracy
#This is a measure of DECREASE in OOB estimates for a particular variable being excluded from 
#a particular averaged tree
##Scale is relative, higher == the variable is a better predictor

#variable importance plot
varImpPlot(Glass.rf) #discuss!

#can we do this better?
names(Glass.rf)
Glass.rf$importance
rFacc <- Glass.rf$importance[, "MeanDecreaseAccuracy"] / max(Glass.rf$importance[, "MeanDecreaseAccuracy"])
rFgini <- Glass.rf$importance[, "MeanDecreaseGini"] / max(Glass.rf$importance[, "MeanDecreaseGini"])

myGoodVar <- (rFacc+rFgini) / 2

myGoodVar <- sort(myGoodVar, dec=T)

plot(myGoodVar, ylim=c(0,1.1), xaxt="n", xlab="Predictors", ylab="Importance")
text(x=c(1:9), y=myGoodVar+0.05, labels=names(myGoodVar), cex= 0.9)

####
# 05 Some data to play with on your own
# Scott's owls data
myOwls <- read.csv("owls.project.csv")
str(myOwls)

# Consider the data - need to turn some into factors
# make a single CART tree and look at predictive power
# use our tree averaging function
# try random forest
# how well does the training data predict real data?
# what are the most important variables?


####
# 06 References
# various web stuff I think is worthwhile, in no order
#https://eight2late.wordpress.com/2016/02/16/a-gentle-introduction-to-decision-trees-using-r/
#http://dni-institute.in/blogs/random-forest-using-r-step-by-step-tutorial/
#http://trevorstephens.com/kaggle-titanic-tutorial/r-part-5-random-forests/
#https://www.analyticsvidhya.com/blog/2016/04/complete-tutorial-tree-based-modeling-scratch-in-python/
#https://www.salford-systems.com/resources/whitepapers/do-splitting-rules-really-matter

###
# Two recent publications where I used random forest in the analysis
# Langan, A.M., Harris, W.E., Barrett, N., Hamshire, C., Wibberley, C., 2016. 
# Benchmarking factor selection and sensitivity: a case study with nursing courses. 
# Studies in Higher Education 0, 1-11.
# 
# Oldekop, J.A., Holmes, G., Harris, W.E., Evans, K.L., 2016. 
# A global assessment of the social and conservation outcomes of protected areas. 
# Conservation Biology 30, 133-141.

###
# some other citations I find useful
# Breiman, L., 2001. 
# Random Forests. 
# Machine Learning 45, 5-32.
# 
# Cutler, D.R., Edwards, T.C., Beard, K.H., Cutler, A., Hess, K.T., Gibson, J., Lawler, J.J., 2007. 
# Random Forests for Classification in Ecology. 
# Ecology 88, 2783-2792.
# 
# Genuer, R., Poggi, J.-M., Tuleau-Malot, C., 2010. 
# Variable selection using random forests. 
# Pattern Recognition Letters 31, 2225-2236.
# 
# Liaw, A., Wiener, M., 2002. 
# Classification and Regression by randomForest. 
# R News 2/3, 18-22.
